
public class ErgasiaEpiskeuhs {
	private String ergasia="";
	private int kostos=0;
	
	public ErgasiaEpiskeuhs(String ergasia, int kostos)
	{
		this.ergasia=ergasia;
		this.kostos=kostos;
	}
	
	public String getErgasia() {
		return ergasia;
	}
	public void setErgasia(String ergasia) {
		this.ergasia = ergasia;
	}
	public int getKostos() {
		return kostos;
	}
	public void setKostos(int kostos) {
		this.kostos = kostos;
	}
	
} 
